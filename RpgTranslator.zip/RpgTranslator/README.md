# RPG Maker Translator (JA → EN)

App Android que traduz os dados de jogos RPG Maker MV/MZ (`data/*.json`), VX Ace (`.rvdata2`), VX (`.rvdata`) e XP (`.rxdata`), inclusive empacotados em `.rgss3a`/`.rgss2a`/`.rgssad` usando ML Kit (grátis, offline, sem chave), DeepL e/ou Google.

- Cache compartilhado: o que já foi traduzido (por qualquer tradutor) não é traduzido nem cobrado de novo.
- Se a cota acabar, o app pode trocar sozinho para o outro tradutor ou parar e salvar uma saída parcial.
- Para continuar depois, rode de novo (pode trocar o tradutor principal).

## Gerar o APK pelo GitHub (sem PC)
1. Crie um repositório no GitHub.
2. Envie o arquivo `RpgTranslator.zip` (Add file → Upload files).
3. Add file → Create new file, nome `.github/workflows/build.yml`, cole o conteúdo do `build.yml` e faça o commit.
4. Aba **Actions** → aguarde o build (uns 3–5 min).
5. Aba **Releases** (ou Actions → Artifacts) → baixe `app-debug.apk` e instale.

## Ainda não suportado
RPG Maker 2000/2003 e Wolf RPG.
