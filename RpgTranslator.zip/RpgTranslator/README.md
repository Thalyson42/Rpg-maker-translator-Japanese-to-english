# RPG Maker Translator (JA → EN)

App Android que traduz os dados de jogos RPG Maker MV/MZ (`data/*.json`), VX Ace (`.rvdata2`), VX (`.rvdata`) e XP (`.rxdata`), inclusive empacotados em `.rgss3a`/`.rgss2a`/`.rgssad` usando ML Kit (grátis, offline, sem chave), DeepL e/ou Google.

- Cache compartilhado: o que já foi traduzido (por qualquer tradutor) não é traduzido nem cobrado de novo.
- Se a cota acabar, o app pode trocar sozinho para o outro tradutor ou parar e salvar uma saída parcial.
- Para continuar depois, rode de novo (pode trocar o tradutor principal).

## Gerar o APK pelo GitHub (sem PC)
1. Crie um repositório no GitHub.
2. Envie o arquivo `RpgTranslator.zip` (Add file → Upload files).
3. Add file → Create new file, nome `.github/workflows/build.yml`, cole o conteúdo do `build.yml` e faça o commit.
4. Aba **Actions** → aguarde o build (uns 3–5 min).
5. Aba **Releases** (ou Actions → Artifacts) → baixe `app-debug.apk` e instale.

## Compatibilidade com plugins e janelas do jogo (MV/MZ)
- **Tags de nota** (ex.: `<コマンド:スキル/魔術,49,魔術,76>`): muitos plugins citam nomes do jogo (tipos de
  habilidade, itens...). O app detecta os nomes citados em tags, traduz **uma vez** e grava a mesma tradução no
  nome e na tag, para o plugin continuar achando o alvo (antes, opções do menu de batalha sumiam). A primeira
  palavra da tag, quando igual a um termo do sistema (攻撃, 防御, アイテム, スキル), é tratada como sintaxe do
  plugin e não é alterada. Textos japoneses em tags que não são nomes (rótulos) **não** são traduzidos; o log avisa.
- **Janelas**: a largura de linha usa a tela e a fonte do `System.json`. Descrições (janela de ajuda) ficam em
  até 2 linhas; mensagens de batalha (`message1..4`, `terms.messages`) ficam em 1 linha e, se não couberem,
  recebem `\}` (fonte menor) em vez de serem cortadas. Nomes largos de tipo de habilidade geram aviso no log.

## Ainda não suportado
RPG Maker 2000/2003 e Wolf RPG.
