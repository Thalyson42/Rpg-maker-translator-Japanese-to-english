package com.rpgtl

import android.content.ContentResolver
import androidx.documentfile.provider.DocumentFile
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import org.json.JSONTokener
import java.io.File
import java.io.IOException

/** Um arquivo de dados do jogo (de uma pasta ou de dentro de um .rgss3a). */
class Source(val name: String, val read: () -> ByteArray)

class Resolved(val sources: List<Source>?, val info: String)

object GameFolders {
    private val DATA_EXT = setOf("json", "rxdata", "rvdata", "rvdata2")

    private fun child(dir: DocumentFile, name: String): DocumentFile? =
        dir.listFiles().firstOrNull { it.name.equals(name, ignoreCase = true) }

    private fun isDataDir(dir: DocumentFile): Boolean =
        dir.isDirectory && dir.listFiles().any { f ->
            val n = f.name?.lowercase() ?: ""
            n.startsWith("system.") && n.substringAfterLast('.') in DATA_EXT
        }

    private fun fromFolder(resolver: ContentResolver, dir: DocumentFile): List<Source> =
        dir.listFiles()
            .filter { it.isFile && it.name != null }
            .sortedBy { it.name }
            .map { f ->
                Source(f.name!!) {
                    resolver.openInputStream(f.uri)?.use { it.readBytes() }
                        ?: throw IOException("Não consegui ler ${f.name}")
                }
            }

    private fun fromArchive(resolver: ContentResolver, arc: DocumentFile): List<Source> {
        val entries = RgssArchive.list(resolver, arc.uri)
        val out = ArrayList<Source>()
        for (e in entries) {
            val p = e.path
            if (!p.lowercase().startsWith("data/")) continue
            val name = p.substring(5)
            if (name.isEmpty() || name.contains('/')) continue
            out.add(Source(name) { RgssArchive.read(resolver, arc.uri, e) })
        }
        return out
    }

    /** Aceita a pasta de dados, a raiz do jogo (com Data/ ou www/data) ou um .rgss3a/.rgss2a/.rgssad. */
    fun resolve(resolver: ContentResolver, root: DocumentFile): Resolved {
        val rootFiles = root.listFiles()
        fun find(name: String): DocumentFile? = rootFiles.firstOrNull { it.name.equals(name, ignoreCase = true) }

        val candidates = ArrayList<DocumentFile>()
        candidates.add(root)
        find("data")?.let { candidates.add(it) }
        find("www")?.let { w -> child(w, "data")?.let { candidates.add(it) } }
        for (c in candidates) {
            if (isDataDir(c)) return Resolved(fromFolder(resolver, c), "")
        }

        val arc = rootFiles.firstOrNull { f ->
            val n = f.name?.lowercase() ?: ""
            n.endsWith(".rgss3a") || n.endsWith(".rgss2a") || n.endsWith(".rgssad")
        }
        if (arc != null) {
            val list = fromArchive(resolver, arc)
            if (list.isNotEmpty()) return Resolved(list, "")
        }

        if (find("RPG_RT.ldb") != null || find("RPG_RT.lmt") != null) {
            return Resolved(null, "RPG Maker 2000/2003 ainda não é suportado.")
        }
        val dataDir = find("Data")
        if (find("Data.wolf") != null || (dataDir != null && child(dataDir, "BasicData") != null)) {
            return Resolved(null, "Wolf RPG ainda não é suportado.")
        }
        return Resolved(
            null,
            "Não encontrei os dados do jogo (System.json, .rxdata, .rvdata, .rvdata2 ou um arquivo .rgss3a)."
        )
    }
}

class GameTranslator(
    private val resolver: ContentResolver,
    private val translator: Translator,
    private val cacheFile: File,
    private val width: Int,
    private val log: (String) -> Unit,
    private val progress: (done: Int, total: Int, status: String) -> Unit
) {
    /** Retorna true se tudo foi traduzido; false se parou por limite (saída parcial). */
    suspend fun run(sources: List<Source>, outRoot: DocumentFile): Boolean = withContext(Dispatchers.IO) {
        val outDir = outRoot.findFile("data_en")?.takeIf { it.isDirectory }
            ?: outRoot.createDirectory("data_en")
            ?: throw IOException("Não foi possível criar a pasta de saída")

        val pipeline = TranslationPipeline(translator, cacheFile, log)
        log("${sources.size} arquivos | tradutor: ${translator.name} | cache: ${pipeline.cacheSize} textos")

        var stopped = false
        try {
            sources.forEachIndexed { idx, src ->
                ensureActive()
                progress(idx, sources.size, "[${src.name}]")
                val kind = kindOf(src.name)
                if (kind == null) {
                    write(outDir, src.name, src.read())
                } else {
                    try {
                        safeTranslate(src, kind, outDir, pipeline, idx, sources.size)
                    } catch (e: ApiException) {
                        stopped = true
                        pipeline.offline = true
                        log("PAROU: ${e.message}")
                        log("Gravando o restante só com o que já está no cache (saída parcial)...")
                        safeTranslate(src, kind, outDir, pipeline, idx, sources.size)
                    }
                }
            }
        } finally {
            pipeline.save()
        }
        progress(sources.size, sources.size, if (stopped) "Parcial" else "Concluído")
        log("Saída: data_en/ | caracteres enviados: ${translator.charsSent} | descartados: ${pipeline.failures}")
        if (stopped) {
            log("Textos ainda sem tradução: ${pipeline.untranslated}. Rode de novo (pode trocar o tradutor) para continuar.")
        }
        !stopped
    }

    private fun kindOf(name: String): String? {
        val ext = name.substringAfterLast('.', "").lowercase()
        val base = name.substringBeforeLast('.')
        return when {
            ext == "json" && EventTextCollector.isTranslatable(name) -> "json"
            (ext == "rxdata" || ext == "rvdata" || ext == "rvdata2") &&
                MarshalTextCollector.isTranslatable(base) -> "marshal"
            else -> null
        }
    }

    private suspend fun CoroutineScope.safeTranslate(
        src: Source, kind: String, outDir: DocumentFile,
        pipe: TranslationPipeline, idx: Int, total: Int
    ) {
        try {
            translateFile(src, kind, outDir, pipe, idx, total)
        } catch (e: ApiException) {
            throw e
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            log("Erro em ${src.name}: ${e.message} (copiado sem traduzir)")
            write(outDir, src.name, src.read())
        }
    }

    private suspend fun CoroutineScope.translateFile(
        src: Source, kind: String, outDir: DocumentFile,
        pipe: TranslationPipeline, idx: Int, total: Int
    ) {
        val name = src.name
        val bytes = src.read()
        val texts: Set<String>
        val finish: (Map<String, String>) -> ByteArray

        if (kind == "json") {
            val text = bytes.toString(Charsets.UTF_8).removePrefix("\uFEFF")
            val root = JSONTokener(text).nextValue()
            val c = EventTextCollector(width)
            if (!c.collect(name, root)) {
                write(outDir, name, bytes)
                return
            }
            texts = c.sources()
            finish = { m -> c.finish(m); root.toString().toByteArray(Charsets.UTF_8) }
        } else {
            val ext = name.substringAfterLast('.').lowercase()
            val base = name.substringBeforeLast('.')
            val root = MarshalReader(bytes).read()
            val w = if (ext == "rxdata") minOf(width, 44) else minOf(width, 48)
            val c = MarshalTextCollector(w, ext == "rxdata", ext == "rvdata2")
            if (!c.collect(base, root)) {
                write(outDir, name, bytes)
                return
            }
            texts = c.sources()
            finish = { m -> c.finish(m); MarshalWriter().write(root) }
        }

        val map = pipe.translateAll(texts) { done, all ->
            progress(idx, total, "[$name] traduzindo $done/$all")
        }
        ensureActive()
        write(outDir, name, finish(map))
        log("$name: ${texts.size} textos únicos")
    }

    private fun write(outDir: DocumentFile, name: String, data: ByteArray) {
        outDir.findFile(name)?.delete()
        val mime = if (name.endsWith(".json", ignoreCase = true)) "application/json" else "application/octet-stream"
        val dst = outDir.createFile(mime, name) ?: throw IOException("Falha ao criar $name")
        resolver.openOutputStream(dst.uri, "wt")?.use { it.write(data) }
            ?: throw IOException("Falha ao gravar $name")
    }
}
