package com.rpgtl

import android.content.ContentResolver
import androidx.documentfile.provider.DocumentFile
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import org.json.JSONTokener
import java.io.File
import java.io.IOException

object GameFolders {
    /** Aceita a pasta "data", a raiz do jogo (com data/) ou a raiz MV (www/data). */
    fun resolveDataDir(root: DocumentFile): DocumentFile? {
        if (root.findFile("System.json") != null) return root
        root.findFile("data")?.let { if (it.isDirectory && it.findFile("System.json") != null) return it }
        root.findFile("www")?.findFile("data")?.let {
            if (it.isDirectory && it.findFile("System.json") != null) return it
        }
        return null
    }
}

class GameTranslator(
    private val resolver: ContentResolver,
    private val translator: Translator,
    private val cacheFile: File,
    private val width: Int,
    private val log: (String) -> Unit,
    private val progress: (done: Int, total: Int, status: String) -> Unit
) {
    /** Retorna true se tudo foi traduzido; false se parou por limite (saída parcial). */
    suspend fun run(dataDir: DocumentFile, outRoot: DocumentFile): Boolean = withContext(Dispatchers.IO) {
        val outDir = outRoot.findFile("data_en")?.takeIf { it.isDirectory }
            ?: outRoot.createDirectory("data_en")
            ?: throw IOException("Não foi possível criar a pasta de saída")

        val files = dataDir.listFiles()
            .filter { it.isFile && it.name != null }
            .sortedBy { it.name }
        val pipeline = TranslationPipeline(translator, cacheFile, log)
        log("${files.size} arquivos | tradutor: ${translator.name} | cache: ${pipeline.cacheSize} textos")

        var stopped = false
        try {
            files.forEachIndexed { idx, f ->
                ensureActive()
                val name = f.name!!
                progress(idx, files.size, "[$name]")
                if (EventTextCollector.isTranslatable(name)) {
                    try {
                        translateFile(f, name, outDir, pipeline, idx, files.size)
                    } catch (e: ApiException) {
                        stopped = true
                        pipeline.offline = true
                        log("PAROU: ${e.message}")
                        log("Gravando o restante só com o que já está no cache (saída parcial)...")
                        translateFile(f, name, outDir, pipeline, idx, files.size)
                    }
                } else {
                    copyFile(f, name, outDir)
                }
            }
        } finally {
            pipeline.save()
        }
        progress(files.size, files.size, if (stopped) "Parcial" else "Concluído")
        log("Saída: data_en/ | caracteres enviados: ${translator.charsSent} | descartados: ${pipeline.failures}")
        if (stopped) log("Textos ainda sem tradução: ${pipeline.untranslated}. Rode de novo (mesmo outro tradutor) para continuar.")
        !stopped
    }

    private suspend fun CoroutineScope.translateFile(
        src: DocumentFile, name: String, outDir: DocumentFile,
        pipe: TranslationPipeline, idx: Int, total: Int
    ) {
        val bytes = resolver.openInputStream(src.uri)?.use { it.readBytes() }
            ?: throw IOException("Não consegui ler $name")
        val text = bytes.toString(Charsets.UTF_8).removePrefix("\uFEFF")
        val root = JSONTokener(text).nextValue()
        val collector = EventTextCollector(width)
        if (!collector.collect(name, root)) {
            copyFile(src, name, outDir)
            return
        }
        val sources = collector.sources()
        val map = pipe.translateAll(sources) { done, all ->
            progress(idx, total, "[$name] traduzindo $done/$all")
        }
        ensureActive()
        collector.finish(map)
        write(outDir, name, root.toString().toByteArray(Charsets.UTF_8))
        log("$name: ${sources.size} textos únicos")
    }

    private fun createOut(outDir: DocumentFile, name: String): DocumentFile {
        outDir.findFile(name)?.delete()
        return outDir.createFile("application/json", name)
            ?: throw IOException("Falha ao criar $name")
    }

    private fun write(outDir: DocumentFile, name: String, data: ByteArray) {
        val dst = createOut(outDir, name)
        resolver.openOutputStream(dst.uri, "wt")?.use { it.write(data) }
            ?: throw IOException("Falha ao gravar $name")
    }

    private fun copyFile(src: DocumentFile, name: String, outDir: DocumentFile) {
        val dst = createOut(outDir, name)
        resolver.openInputStream(src.uri)?.use { i ->
            resolver.openOutputStream(dst.uri, "wt")?.use { o -> i.copyTo(o) }
        }
    }
}
